1. Run `sudo docker-compose up`
2. Post {"name": "hihi", "id": "22"} to http://localhost:4567/post/data
