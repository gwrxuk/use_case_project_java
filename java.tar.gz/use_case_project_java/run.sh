#!/bin/bash

java -jar /server/target/usecase-1.0-SNAPSHOT.jar
